import { start } from "./router.js";

    console.log("DOM is mounted and ready");
    start();
