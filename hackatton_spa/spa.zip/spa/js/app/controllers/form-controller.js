import formView  from "../views/form-view.js";


export const start = () => formView.renderButton();