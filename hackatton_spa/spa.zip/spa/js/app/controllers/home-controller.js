import { render } from "../views/home-view.js";


export const start = () => render();
 