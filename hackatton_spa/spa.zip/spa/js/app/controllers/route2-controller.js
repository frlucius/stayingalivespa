export const start = () => console.log("Hello");
